<?php
 
//Server Settting
define ("MT4_SERVER","192.168.15.10");
define ("MT4_PORT","443");
define ("MT4_MASTER","PASSWORD");

// Return Messages from MT4
define ("1", "Invalid Data");
define ("2", "Internal Error");
define ("3", "General Error");
define ("4", "No Change");
define ("5", "Invalid Login");
define ("6", "No Enough Money");
define ("7", "Client is not related to this agent");
define ("8", "Client Credit is less than credit out amount");
define ("9", "Simple password , should contain numbers and letters and above 5 characters");
define ("0", "Success");

?>
